package com.hp.genericsex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class WithOutGenericsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List valuesList = new ArrayList();
		
		valuesList.add(10);
		valuesList.add("Sample");
		
		valuesList.add(23.80);
		
		Iterator itr = valuesList.iterator();
		
		while (itr.hasNext()) {
			Object obj = itr.next();
			System.out.println(obj);
		}
		
		List<String> strLst = new ArrayList<String>();
		
		strLst.add("sample1");
		//strLst.add(100); //compile time error., 
		strLst.add("Sample2");
		
		Iterator<String> strLstItr = strLst.iterator();
		
		while (strLstItr.hasNext()) {
			String obj = strLstItr.next();
			System.out.println(obj);
		}
		
		
	}

}
